tar cvzf chapter_2.tar.gz *.ipynb
